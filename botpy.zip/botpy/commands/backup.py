"""
Backup commands for FermixBot
Команды для резервного копирования сервера
"""
import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)


class BackupCog(commands.Cog):
    """Команды резервного копирования"""
    
    def __init__(self, bot):
        self.bot = bot
    


async def setup(bot):
    await bot.add_cog(BackupCog(bot))
