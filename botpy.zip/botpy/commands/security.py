"""
Security features for FermixBot - DEPRECATED
All security features moved to admin panel (/admin -> Безопасность)
"""
import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)


class SecurityCog(commands.Cog):
    """Security features - now accessible through admin panel"""
    
    def __init__(self, bot):
        self.bot = bot


async def setup(bot):
    await bot.add_cog(SecurityCog(bot))
