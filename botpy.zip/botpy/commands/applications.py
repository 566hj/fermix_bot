"""
Application system commands and UI for FermixBot
Handles staff application forms, review process, and DM communication
"""
import discord
from discord import ui, app_commands
from discord.ext import commands
import logging
from datetime import datetime
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)


# ============================================================
# Modal for filling out application (handles multi-page if >5 questions)
# ============================================================

class ApplicationModal(ui.Modal):
    """Modal for a single page of application questions (max 5 per modal)"""

    def __init__(self, bot, app_type: dict, questions: list, page: int = 0, collected_answers: list = None):
        self.bot = bot
        self.app_type = app_type
        self.all_questions = questions
        self.page = page
        self.collected_answers = collected_answers or []

        # Calculate page slice
        self.page_size = 5
        start = page * self.page_size
        end = start + self.page_size
        self.page_questions = questions[start:end]
        self.total_pages = (len(questions) + self.page_size - 1) // self.page_size

        title = app_type['name']
        if self.total_pages > 1:
            title = f"{app_type['name']} ({page + 1}/{self.total_pages})"
        if len(title) > 45:
            title = title[:42] + "..."

        super().__init__(title=title, timeout=600)

        # Add text inputs for this page's questions
        self.inputs = []
        for q in self.page_questions:
            label = q['question']
            if len(label) > 45:
                label = label[:42] + "..."
            text_input = ui.TextInput(
                label=label,
                style=discord.TextStyle.paragraph,
                placeholder=q.get('placeholder') or "Введите ваш ответ...",
                required=q.get('required', True),
                max_length=min(q.get('max_length', 1000), 4000),
            )
            self.inputs.append(text_input)
            self.add_item(text_input)

    async def on_submit(self, interaction: discord.Interaction):
        # Collect answers from this page
        for q, inp in zip(self.page_questions, self.inputs):
            self.collected_answers.append({
                'question': q['question'],
                'answer': inp.value or "",
            })

        # Check if there are more pages
        next_page = self.page + 1
        if next_page < self.total_pages:
            modal = ApplicationModal(
                self.bot, self.app_type, self.all_questions,
                page=next_page, collected_answers=self.collected_answers
            )
            await interaction.response.send_modal(modal)
            return

        # All pages done - submit application
        await interaction.response.defer(ephemeral=True)

        service = self.bot.application_service
        app_id = await service.create_application(
            guild_id=interaction.guild.id,
            user_id=interaction.user.id,
            app_type_id=self.app_type['id'],
            answers=self.collected_answers,
        )

        if not app_id:
            await interaction.followup.send(
                "Произошла ошибка при подаче заявки. Попробуйте позже.",
                ephemeral=True
            )
            return

        # Send to applications channel
        msg = await service.send_application_to_channel(interaction.guild, app_id)

        if msg:
            await interaction.followup.send(
                f"Ваша заявка **{self.app_type['name']}** успешно подана! (#{app_id})\nОжидайте рассмотрения.",
                ephemeral=True
            )
            # DM confirmation
            try:
                dm_embed = discord.Embed(
                    title="Заявка подана",
                    description=f"Ваша заявка **{self.app_type['name']}** на сервере **{interaction.guild.name}** успешно подана.\nНомер заявки: **#{app_id}**\nОжидайте рассмотрения.",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                await interaction.user.send(embed=dm_embed)
            except discord.Forbidden:
                pass
        else:
            await interaction.followup.send(
                "Заявка сохранена, но канал заявок не настроен. Обратитесь к администратору.",
                ephemeral=True
            )


# ============================================================
# Panel with buttons to submit applications (persistent)
# ============================================================

class ApplicationPanelView(ui.View):
    """Persistent panel with buttons for each application type"""

    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @classmethod
    async def create(cls, bot, guild_id: int):
        """Create the panel view with dynamic buttons"""
        view = cls(bot)
        service = bot.application_service
        app_types = await service.get_app_types(guild_id)

        for i, app_type in enumerate(app_types):
            questions = await service.get_questions(app_type['id'])
            if not questions:
                continue
            button = ApplicationSubmitButton(bot, app_type, row=i // 5)
            view.add_item(button)

        return view


class ApplicationSubmitButton(ui.Button):
    """Button for submitting a specific application type"""

    def __init__(self, bot, app_type: dict, row: int = 0):
        self.bot = bot
        self.app_type = app_type
        super().__init__(
            label=app_type['name'],
            style=discord.ButtonStyle.blurple,
            custom_id=f"app_submit_{app_type['id']}",
            row=row,
        )

    async def callback(self, interaction: discord.Interaction):
        service = self.bot.application_service
        questions = await service.get_questions(self.app_type['id'])

        if not questions:
            await interaction.response.send_message(
                "Для этой заявки ещё не настроены вопросы.",
                ephemeral=True
            )
            return

        # Check if user already has a pending application of this type
        existing = self.bot.application_service.db.fetch_one(
            "SELECT id FROM applications WHERE guild_id = ? AND user_id = ? AND app_type_id = ? AND status IN ('pending', 'reviewing', 'call_pending')",
            (interaction.guild.id, interaction.user.id, self.app_type['id'])
        )
        if existing:
            await interaction.response.send_message(
                "У вас уже есть активная заявка этого типа. Дождитесь её рассмотрения.",
                ephemeral=True
            )
            return

        modal = ApplicationModal(self.bot, self.app_type, questions)
        await interaction.response.send_modal(modal)


# ============================================================
# Control buttons on the application message (review/approve/reject/call)
# ============================================================

class ApplicationControlView(ui.View):
    """Buttons for managing an application (on the application embed message)"""

    def __init__(self, bot, app_id: int):
        super().__init__(timeout=None)
        self.bot = bot
        self.app_id = app_id

    @ui.button(label="Рассмотреть", style=discord.ButtonStyle.blurple, custom_id="app_review", row=0)
    async def review(self, interaction: discord.Interaction, button: ui.Button):
        service = self.bot.application_service
        app = await service.get_application(self.app_id)
        if not app:
            await interaction.response.send_message("Заявка не найдена.", ephemeral=True)
            return

        if app['status'] != 'pending':
            await interaction.response.send_message("Эта заявка уже рассматривается.", ephemeral=True)
            return

        await interaction.response.defer()

        # Update status
        await service.update_application(self.app_id, status='reviewing', reviewed_by=interaction.user.id)

        # Assign pending role to applicant
        app_type = await service.get_app_type(app['app_type_id'])
        member = interaction.guild.get_member(app['user_id'])
        if member and app_type and app_type.get('pending_role_id'):
            role = interaction.guild.get_role(app_type['pending_role_id'])
            if role:
                try:
                    await member.add_roles(role, reason=f"Заявка #{self.app_id} на рассмотрении")
                except discord.HTTPException:
                    pass

        # Create thread from the message
        thread = None
        try:
            thread = await interaction.message.create_thread(
                name=f"Заявка #{self.app_id} - {member.display_name if member else app['user_id']}",
                auto_archive_duration=1440
            )
            await service.update_application(self.app_id, thread_id=thread.id)
            await thread.send(
                f"{interaction.user.mention} взял(а) заявку на рассмотрение.\n"
                f"Сообщения в этой ветке будут пересылаться подавшему в ЛС."
            )
        except discord.HTTPException as e:
            logger.error(f"Error creating thread for app {self.app_id}: {e}")

        # Update embed
        embed = interaction.message.embeds[0] if interaction.message.embeds else None
        if embed:
            embed.color = discord.Color.orange()
            for i, field in enumerate(embed.fields):
                if field.name == "Статус":
                    embed.set_field_at(i, name="Статус", value=f"Рассматривается ({interaction.user.mention})", inline=True)
                    break
            await interaction.message.edit(embed=embed, view=self)

        # DM applicant
        if member:
            try:
                dm_embed = discord.Embed(
                    title="Ваша заявка рассматривается",
                    description=(
                        f"Заявка **{app_type['name'] if app_type else ''}** на сервере **{interaction.guild.name}** взята на рассмотрение.\n"
                        f"Рассматривает: {interaction.user.mention}\n\n"
                        f"Вы можете отвечать в этом чате - сообщения будут пересланы проверяющему."
                    ),
                    color=discord.Color.orange()
                )
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                if thread:
                    await thread.send("Не удалось отправить сообщение подавшему в ЛС (закрыты ЛС).")

    @ui.button(label="Одобрить", style=discord.ButtonStyle.green, custom_id="app_approve", row=0)
    async def approve(self, interaction: discord.Interaction, button: ui.Button):
        service = self.bot.application_service
        app = await service.get_application(self.app_id)
        if not app:
            await interaction.response.send_message("Заявка не найдена.", ephemeral=True)
            return

        if app['status'] not in ('reviewing', 'call_pending'):
            await interaction.response.send_message("Сначала нужно взять заявку на рассмотрение.", ephemeral=True)
            return

        await interaction.response.defer()

        app_type = await service.get_app_type(app['app_type_id'])
        member = interaction.guild.get_member(app['user_id'])

        # Remove pending role, add approved role
        if member and app_type:
            if app_type.get('pending_role_id'):
                pending_role = interaction.guild.get_role(app_type['pending_role_id'])
                if pending_role:
                    try:
                        await member.remove_roles(pending_role, reason=f"Заявка #{self.app_id} одобрена")
                    except discord.HTTPException:
                        pass
            if app_type.get('role_id'):
                approved_role = interaction.guild.get_role(app_type['role_id'])
                if approved_role:
                    try:
                        await member.add_roles(approved_role, reason=f"Заявка #{self.app_id} одобрена")
                    except discord.HTTPException:
                        pass

        await service.update_application(
            self.app_id,
            status='approved',
            reviewed_by=interaction.user.id,
            reviewed_at=datetime.now().isoformat()
        )

        # Update embed
        embed = interaction.message.embeds[0] if interaction.message.embeds else None
        if embed:
            embed.color = discord.Color.green()
            for i, field in enumerate(embed.fields):
                if field.name == "Статус":
                    embed.set_field_at(i, name="Статус", value=f"Одобрена ({interaction.user.mention})", inline=True)
                    break

        # Disable all buttons
        for item in self.children:
            item.disabled = True
        await interaction.message.edit(embed=embed, view=self)

        # Archive thread
        if app.get('thread_id'):
            thread = interaction.guild.get_thread(app['thread_id'])
            if thread:
                await thread.send(f"Заявка **одобрена** пользователем {interaction.user.mention}.")
                try:
                    await thread.edit(archived=True, locked=True)
                except discord.HTTPException:
                    pass

        # DM applicant
        if member:
            try:
                dm_embed = discord.Embed(
                    title="Заявка одобрена!",
                    description=(
                        f"Ваша заявка **{app_type['name'] if app_type else ''}** на сервере **{interaction.guild.name}** была **одобрена**!\n"
                        f"Рассмотрел: {interaction.user.mention}"
                    ),
                    color=discord.Color.green()
                )
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass

        # Transcript
        await service.send_transcript(interaction.guild, self.app_id, 'approved')

    @ui.button(label="Отклонить", style=discord.ButtonStyle.red, custom_id="app_reject", row=0)
    async def reject(self, interaction: discord.Interaction, button: ui.Button):
        service = self.bot.application_service
        app = await service.get_application(self.app_id)
        if not app:
            await interaction.response.send_message("Заявка не найдена.", ephemeral=True)
            return

        if app['status'] not in ('reviewing', 'call_pending', 'pending'):
            await interaction.response.send_message("Невозможно отклонить заявку в текущем статусе.", ephemeral=True)
            return

        modal = RejectReasonModal(self.bot, self.app_id)
        await interaction.response.send_modal(modal)

    @ui.button(label="Ожидание обзвона", style=discord.ButtonStyle.secondary, custom_id="app_call", row=1)
    async def call_pending(self, interaction: discord.Interaction, button: ui.Button):
        service = self.bot.application_service
        app = await service.get_application(self.app_id)
        if not app:
            await interaction.response.send_message("Заявка не найдена.", ephemeral=True)
            return

        if app['status'] not in ('reviewing',):
            await interaction.response.send_message("Сначала нужно взять заявку на рассмотрение.", ephemeral=True)
            return

        await interaction.response.defer()

        await service.update_application(self.app_id, status='call_pending')

        settings = await service.get_settings(interaction.guild.id)
        voice_channel_id = settings.get('voice_channel_id')

        # Update embed
        embed = interaction.message.embeds[0] if interaction.message.embeds else None
        if embed:
            embed.color = discord.Color.gold()
            for i, field in enumerate(embed.fields):
                if field.name == "Статус":
                    embed.set_field_at(i, name="Статус", value=f"Ожидание обзвона ({interaction.user.mention})", inline=True)
                    break
            await interaction.message.edit(embed=embed, view=self)

        # DM applicant with voice channel info
        member = interaction.guild.get_member(app['user_id'])
        app_type = await service.get_app_type(app['app_type_id'])
        if member:
            try:
                voice_text = ""
                if voice_channel_id:
                    voice_channel = interaction.guild.get_channel(voice_channel_id)
                    if voice_channel:
                        voice_text = f"\n\nПодключитесь к голосовому каналу: **{voice_channel.name}**\n{voice_channel.jump_url}"

                dm_embed = discord.Embed(
                    title="Ожидание обзвона",
                    description=(
                        f"По вашей заявке **{app_type['name'] if app_type else ''}** на сервере **{interaction.guild.name}** "
                        f"назначен обзвон.{voice_text}"
                    ),
                    color=discord.Color.gold()
                )
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                if app.get('thread_id'):
                    thread = interaction.guild.get_thread(app['thread_id'])
                    if thread:
                        await thread.send("Не удалось отправить уведомление об обзвоне в ЛС (закрыты ЛС).")

        if app.get('thread_id'):
            thread = interaction.guild.get_thread(app['thread_id'])
            if thread:
                await thread.send(f"Статус изменен на **ожидание обзвона** пользователем {interaction.user.mention}.")


class RejectReasonModal(ui.Modal):
    """Modal for entering rejection reason"""

    def __init__(self, bot, app_id: int):
        super().__init__(title="Причина отклонения", timeout=300)
        self.bot = bot
        self.app_id = app_id

        self.reason_input = ui.TextInput(
            label="Причина",
            style=discord.TextStyle.paragraph,
            placeholder="Укажите причину отклонения заявки...",
            required=True,
            max_length=1000,
        )
        self.add_item(self.reason_input)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        service = self.bot.application_service
        app = await service.get_application(self.app_id)
        if not app:
            return

        reason = self.reason_input.value
        app_type = await service.get_app_type(app['app_type_id'])
        member = interaction.guild.get_member(app['user_id'])

        # Remove pending role
        if member and app_type and app_type.get('pending_role_id'):
            pending_role = interaction.guild.get_role(app_type['pending_role_id'])
            if pending_role:
                try:
                    await member.remove_roles(pending_role, reason=f"Заявка #{self.app_id} отклонена")
                except discord.HTTPException:
                    pass

        await service.update_application(
            self.app_id,
            status='rejected',
            reviewed_by=interaction.user.id,
            review_reason=reason,
            reviewed_at=datetime.now().isoformat()
        )

        # Update the original message
        # Find the message in the applications channel
        settings = await service.get_settings(interaction.guild.id)
        ch_id = settings.get('applications_channel_id')
        if ch_id and app.get('message_id'):
            channel = interaction.guild.get_channel(ch_id)
            if channel:
                try:
                    msg = await channel.fetch_message(app['message_id'])
                    embed = msg.embeds[0] if msg.embeds else None
                    if embed:
                        embed.color = discord.Color.red()
                        for i, field in enumerate(embed.fields):
                            if field.name == "Статус":
                                embed.set_field_at(i, name="Статус", value=f"Отклонена ({interaction.user.mention})", inline=True)
                                break
                        embed.add_field(name="Причина отклонения", value=reason, inline=False)

                    view = ApplicationControlView(self.bot, self.app_id)
                    for item in view.children:
                        item.disabled = True
                    await msg.edit(embed=embed, view=view)
                except discord.HTTPException:
                    pass

        # Archive thread
        if app.get('thread_id'):
            thread = interaction.guild.get_thread(app['thread_id'])
            if thread:
                await thread.send(
                    f"Заявка **отклонена** пользователем {interaction.user.mention}.\n"
                    f"**Причина:** {reason}"
                )
                try:
                    await thread.edit(archived=True, locked=True)
                except discord.HTTPException:
                    pass

        # DM applicant
        if member:
            try:
                dm_embed = discord.Embed(
                    title="Заявка отклонена",
                    description=(
                        f"Ваша заявка **{app_type['name'] if app_type else ''}** на сервере **{interaction.guild.name}** была **отклонена**.\n\n"
                        f"**Причина:** {reason}"
                    ),
                    color=discord.Color.red()
                )
                await member.send(embed=dm_embed)
            except discord.Forbidden:
                pass

        # Transcript
        await service.send_transcript(interaction.guild, self.app_id, 'rejected')

        await interaction.followup.send("Заявка отклонена.", ephemeral=True)


# ============================================================
# Cog with DM <-> Thread message relay
# ============================================================

class ApplicationsCog(commands.Cog):
    """Cog for application system - handles DM relay and persistent views"""

    def __init__(self, bot):
        self.bot = bot
        logger.info("ApplicationsCog loaded")

    @commands.Cog.listener()
    async def on_ready(self):
        """Register persistent views on startup"""
        # We register a dummy ApplicationControlView so Discord.py recognizes custom_ids
        # The actual app_id is resolved from the message
        self.bot.add_view(ApplicationControlView(self.bot, 0))
        logger.info("Application persistent views registered")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Handle DM -> Thread relay and Thread -> DM relay"""
        if message.author.bot:
            return

        service = getattr(self.bot, 'application_service', None)
        if not service:
            return

        # --- DM from applicant -> Thread ---
        if isinstance(message.channel, discord.DMChannel):
            await self._handle_dm_to_thread(message, service)
            return

        # --- Thread message from reviewer -> DM ---
        if isinstance(message.channel, discord.Thread):
            await self._handle_thread_to_dm(message, service)

    async def _handle_dm_to_thread(self, message: discord.Message, service):
        """Forward DM from applicant to the review thread"""
        # Find active application with a thread for this user
        row = service.db.fetch_one(
            "SELECT id, guild_id, thread_id FROM applications WHERE user_id = ? AND status IN ('reviewing', 'call_pending') AND thread_id IS NOT NULL ORDER BY created_at DESC LIMIT 1",
            (message.author.id,)
        )
        if not row:
            return

        app_id, guild_id, thread_id = row
        guild = self.bot.get_guild(guild_id)
        if not guild:
            return

        thread = guild.get_thread(thread_id)
        if not thread:
            # Try to fetch it
            try:
                thread = await guild.fetch_channel(thread_id)
            except discord.HTTPException:
                return

        embed = discord.Embed(
            description=message.content or "",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.set_author(
            name=str(message.author),
            icon_url=message.author.display_avatar.url
        )

        # Handle attachments
        files = []
        for att in message.attachments:
            try:
                files.append(await att.to_file())
            except discord.HTTPException:
                pass

        if embed.description or files:
            await thread.send(embed=embed, files=files if files else None)

        # React to confirm delivery
        try:
            await message.add_reaction("\u2709\ufe0f")
        except discord.HTTPException:
            pass

    async def _handle_thread_to_dm(self, message: discord.Message, service):
        """Forward thread message from reviewer to applicant DM"""
        # Check if this thread belongs to an active application
        row = service.db.fetch_one(
            "SELECT id, user_id, guild_id FROM applications WHERE thread_id = ? AND status IN ('reviewing', 'call_pending')",
            (message.channel.id,)
        )
        if not row:
            return

        app_id, user_id, guild_id = row

        # Don't relay bot messages or the applicant's own forwarded messages
        if message.author.id == user_id:
            return

        guild = self.bot.get_guild(guild_id)
        if not guild:
            return

        member = guild.get_member(user_id)
        if not member:
            return

        embed = discord.Embed(
            description=message.content or "",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        embed.set_author(
            name=f"{message.author.display_name} (Проверяющий)",
            icon_url=message.author.display_avatar.url
        )
        embed.set_footer(text=f"Сервер: {guild.name}")

        files = []
        for att in message.attachments:
            try:
                files.append(await att.to_file())
            except discord.HTTPException:
                pass

        try:
            await member.send(embed=embed, files=files if files else None)
        except discord.Forbidden:
            await message.channel.send("Не удалось отправить сообщение подавшему (ЛС закрыты).")
            return

        try:
            await message.add_reaction("\u2709\ufe0f")
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(ApplicationsCog(bot))
