"""
Application service for FermixBot
Handles staff application logic - creating, reviewing, approving, rejecting applications
"""
import discord
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


class ApplicationService:
    """Service for managing staff applications"""

    def __init__(self, db, bot):
        self.db = db
        self.bot = bot
        logger.info("ApplicationService initialized")

    # =====================
    # Application Types
    # =====================

    async def get_app_types(self, guild_id: int) -> List[Dict[str, Any]]:
        """Get all application types for a guild"""
        rows = self.db.fetch_all(
            "SELECT id, guild_id, name, role_id, review_role_id, pending_role_id FROM application_types WHERE guild_id = ?",
            (guild_id,)
        )
        result = []
        for row in rows:
            result.append({
                'id': row[0],
                'guild_id': row[1],
                'name': row[2],
                'role_id': row[3],
                'review_role_id': row[4],
                'pending_role_id': row[5],
            })
        return result

    async def get_app_type(self, type_id: int) -> Optional[Dict[str, Any]]:
        """Get a single application type by ID"""
        row = self.db.fetch_one(
            "SELECT id, guild_id, name, role_id, review_role_id, pending_role_id FROM application_types WHERE id = ?",
            (type_id,)
        )
        if not row:
            return None
        return {
            'id': row[0],
            'guild_id': row[1],
            'name': row[2],
            'role_id': row[3],
            'review_role_id': row[4],
            'pending_role_id': row[5],
        }

    async def create_app_type(self, guild_id: int, name: str) -> int:
        """Create a new application type, returns its ID"""
        cursor = self.db.execute(
            "INSERT INTO application_types (guild_id, name) VALUES (?, ?)",
            (guild_id, name)
        )
        type_id = cursor.lastrowid
        logger.info(f"Created application type '{name}' (id={type_id}) for guild {guild_id}")
        return type_id

    async def update_app_type(self, type_id: int, **kwargs) -> bool:
        """Update application type fields (role_id, review_role_id, pending_role_id, name)"""
        allowed = {'name', 'role_id', 'review_role_id', 'pending_role_id'}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [type_id]
        self.db.execute(
            f"UPDATE application_types SET {set_clause} WHERE id = ?",
            tuple(values)
        )
        logger.info(f"Updated application type {type_id}: {updates}")
        return True

    async def delete_app_type(self, type_id: int) -> bool:
        """Delete an application type and its questions"""
        self.db.execute("DELETE FROM application_questions WHERE app_type_id = ?", (type_id,))
        self.db.execute("DELETE FROM application_types WHERE id = ?", (type_id,))
        logger.info(f"Deleted application type {type_id}")
        return True

    # =====================
    # Questions
    # =====================

    async def get_questions(self, app_type_id: int) -> List[Dict[str, Any]]:
        """Get questions for an application type, ordered by position"""
        rows = self.db.fetch_all(
            "SELECT id, question, placeholder, required, max_length, position FROM application_questions WHERE app_type_id = ? ORDER BY position",
            (app_type_id,)
        )
        result = []
        for row in rows:
            result.append({
                'id': row[0],
                'question': row[1],
                'placeholder': row[2],
                'required': bool(row[3]),
                'max_length': row[4],
                'position': row[5],
            })
        return result

    async def add_question(self, app_type_id: int, question: str, placeholder: str = None, required: bool = True, max_length: int = 1000) -> int:
        """Add a question to an application type"""
        # Get next position
        row = self.db.fetch_one(
            "SELECT COALESCE(MAX(position), -1) + 1 FROM application_questions WHERE app_type_id = ?",
            (app_type_id,)
        )
        position = row[0] if row else 0
        cursor = self.db.execute(
            "INSERT INTO application_questions (app_type_id, question, placeholder, required, max_length, position) VALUES (?, ?, ?, ?, ?, ?)",
            (app_type_id, question, placeholder, int(required), max_length, position)
        )
        logger.info(f"Added question to app type {app_type_id}: '{question}'")
        return cursor.lastrowid

    async def remove_question(self, question_id: int) -> bool:
        """Remove a question"""
        self.db.execute("DELETE FROM application_questions WHERE id = ?", (question_id,))
        logger.info(f"Removed question {question_id}")
        return True

    # =====================
    # Settings
    # =====================

    async def get_settings(self, guild_id: int) -> Dict[str, Any]:
        """Get application settings for a guild"""
        row = self.db.fetch_one(
            "SELECT applications_channel_id, transcript_channel_id, voice_channel_id FROM application_settings WHERE guild_id = ?",
            (guild_id,)
        )
        if row:
            return {
                'applications_channel_id': row[0],
                'transcript_channel_id': row[1],
                'voice_channel_id': row[2],
            }
        return {
            'applications_channel_id': None,
            'transcript_channel_id': None,
            'voice_channel_id': None,
        }

    async def update_setting(self, guild_id: int, field: str, value) -> bool:
        """Update a single application setting"""
        allowed = {'applications_channel_id', 'transcript_channel_id', 'voice_channel_id'}
        if field not in allowed:
            return False
        existing = self.db.fetch_one(
            "SELECT guild_id FROM application_settings WHERE guild_id = ?",
            (guild_id,)
        )
        if existing:
            self.db.execute(
                f"UPDATE application_settings SET {field} = ? WHERE guild_id = ?",
                (value, guild_id)
            )
        else:
            self.db.execute(
                f"INSERT INTO application_settings (guild_id, {field}) VALUES (?, ?)",
                (guild_id, value)
            )
        logger.info(f"Updated application setting {field}={value} for guild {guild_id}")
        return True

    # =====================
    # Applications
    # =====================

    async def create_application(self, guild_id: int, user_id: int, app_type_id: int, answers: List[Dict[str, str]]) -> Optional[int]:
        """Create an application and save answers. Returns application ID."""
        try:
            cursor = self.db.execute(
                "INSERT INTO applications (guild_id, user_id, app_type_id) VALUES (?, ?, ?)",
                (guild_id, user_id, app_type_id)
            )
            app_id = cursor.lastrowid
            for ans in answers:
                self.db.execute(
                    "INSERT INTO application_answers (application_id, question, answer) VALUES (?, ?, ?)",
                    (app_id, ans['question'], ans['answer'])
                )
            logger.info(f"Created application {app_id} from user {user_id} for type {app_type_id}")
            return app_id
        except Exception as e:
            logger.error(f"Error creating application: {e}", exc_info=True)
            return None

    async def get_application(self, app_id: int) -> Optional[Dict[str, Any]]:
        """Get application by ID"""
        row = self.db.fetch_one(
            "SELECT id, guild_id, user_id, app_type_id, thread_id, message_id, status, reviewed_by, review_reason, created_at, reviewed_at FROM applications WHERE id = ?",
            (app_id,)
        )
        if not row:
            return None
        return {
            'id': row[0], 'guild_id': row[1], 'user_id': row[2], 'app_type_id': row[3],
            'thread_id': row[4], 'message_id': row[5], 'status': row[6],
            'reviewed_by': row[7], 'review_reason': row[8],
            'created_at': row[9], 'reviewed_at': row[10],
        }

    async def get_application_answers(self, app_id: int) -> List[Dict[str, str]]:
        """Get all answers for an application"""
        rows = self.db.fetch_all(
            "SELECT question, answer FROM application_answers WHERE application_id = ?",
            (app_id,)
        )
        return [{'question': r[0], 'answer': r[1]} for r in rows]

    async def update_application(self, app_id: int, **kwargs) -> bool:
        """Update application fields"""
        allowed = {'thread_id', 'message_id', 'status', 'reviewed_by', 'review_reason', 'reviewed_at'}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [app_id]
        self.db.execute(
            f"UPDATE applications SET {set_clause} WHERE id = ?",
            tuple(values)
        )
        return True

    async def send_application_to_channel(self, guild: discord.Guild, app_id: int) -> Optional[discord.Message]:
        """Send the application embed to the applications channel and return the message"""
        app = await self.get_application(app_id)
        if not app:
            return None

        settings = await self.get_settings(guild.id)
        channel_id = settings.get('applications_channel_id')
        if not channel_id:
            logger.warning(f"No applications channel set for guild {guild.id}")
            return None

        channel = guild.get_channel(channel_id)
        if not channel:
            logger.warning(f"Applications channel {channel_id} not found in guild {guild.id}")
            return None

        app_type = await self.get_app_type(app.get('app_type_id'))
        answers = await self.get_application_answers(app_id)
        member = guild.get_member(app['user_id'])

        embed = discord.Embed(
            title=f"Заявка: {app_type['name'] if app_type else 'Неизвестно'}",
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        embed.set_author(
            name=str(member) if member else f"ID: {app['user_id']}",
            icon_url=member.display_avatar.url if member else None
        )
        embed.add_field(name="Подавший", value=f"{member.mention if member else app['user_id']}", inline=True)
        embed.add_field(name="Тип заявки", value=app_type['name'] if app_type else "?", inline=True)
        embed.add_field(name="Статус", value="Ожидает рассмотрения", inline=True)

        for ans in answers:
            value = ans['answer']
            if len(value) > 1024:
                value = value[:1021] + "..."
            embed.add_field(name=ans['question'], value=value, inline=False)

        embed.set_footer(text=f"ID заявки: {app_id}")

        # Import here to avoid circular imports
        from commands.applications import ApplicationControlView
        view = ApplicationControlView(self.bot, app_id)
        msg = await channel.send(embed=embed, view=view)

        await self.update_application(app_id, message_id=msg.id)
        return msg

    async def send_transcript(self, guild: discord.Guild, app_id: int, status: str):
        """Send a transcript of the application to the transcript channel"""
        settings = await self.get_settings(guild.id)
        channel_id = settings.get('transcript_channel_id')
        if not channel_id:
            return

        channel = guild.get_channel(channel_id)
        if not channel:
            return

        app = await self.get_application(app_id)
        if not app:
            return

        app_type = await self.get_app_type(app['app_type_id'])
        answers = await self.get_application_answers(app_id)
        member = guild.get_member(app['user_id'])
        reviewer = guild.get_member(app['reviewed_by']) if app['reviewed_by'] else None

        status_text = {
            'approved': 'Одобрена',
            'rejected': 'Отклонена',
            'call_pending': 'Ожидание обзвона',
        }.get(status, status)

        color = {
            'approved': discord.Color.green(),
            'rejected': discord.Color.red(),
            'call_pending': discord.Color.orange(),
        }.get(status, discord.Color.light_grey())

        embed = discord.Embed(
            title=f"Транскрипт заявки #{app_id}",
            color=color,
            timestamp=datetime.now()
        )
        embed.add_field(name="Тип", value=app_type['name'] if app_type else "?", inline=True)
        embed.add_field(name="Подавший", value=member.mention if member else str(app['user_id']), inline=True)
        embed.add_field(name="Статус", value=status_text, inline=True)
        if reviewer:
            embed.add_field(name="Рассмотрел", value=reviewer.mention, inline=True)
        if app.get('review_reason'):
            embed.add_field(name="Причина", value=app['review_reason'], inline=False)

        for ans in answers:
            value = ans['answer']
            if len(value) > 1024:
                value = value[:1021] + "..."
            embed.add_field(name=ans['question'], value=value, inline=False)

        await channel.send(embed=embed)
